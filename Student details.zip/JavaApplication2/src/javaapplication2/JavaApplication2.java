/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author king
 */
public class JavaApplication2 {
    int i,j;
    void run()
    {
        for(i=1;i<=4;i++)
        {
            for(j=1;j<i;j++)
            {
                System.out.print("*");
            }
            System.out.println();
        }    

    }        
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JavaApplication2 obj = new JavaApplication2();
        obj.run();// TODO code application logic here
    }
    
}
